document.addEventListener('DOMContentLoaded', () => {
    const addButton = document.getElementById('addTask');
    const taskInput = document.getElementById('taskInput');
    const taskList = document.getElementById('taskList');

    const apiUrl = 'https://your-replit-backend-url.repl.co/api/todos'; // Replace with your Replit backend URL

    const fetchTodos = async () => {
        const response = await fetch(apiUrl);
        const todos = await response.json();
        todos.forEach(todo => addToTaskList(todo));
    };

    const addToTaskList = (todo) => {
        const listItem = document.createElement('li');
        listItem.textContent = todo.task;

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', async () => {
            await fetch(`${apiUrl}/${todo.id}`, { method: 'DELETE' });
            taskList.removeChild(listItem);
        });

        listItem.appendChild(deleteButton);
        taskList.appendChild(listItem);
    };

    addButton.addEventListener('click', async () => {
        const taskValue = taskInput.value.trim();
        if (taskValue === '') return;

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ task: taskValue, completed: false })
        });

        const newTodo = await response.json();
        addToTaskList(newTodo);
    });

    fetchTodos();
});
